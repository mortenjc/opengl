#include <os2.h>
#include <gl.h>
#include <glu.h>
#include <aux.h>
#include <ithread.hpp>
#include "glwindow.hpp"

#define FOVY            70.0
#define MINVIEWDISTANCE 0.1
#define MAXVIEWDISTANCE 1000.0

// GLpaint destructor handler
Boolean GLPaintDestroy::dispatchHandlerEvent( IEvent &event )
{
   Boolean stopDispatching = false;
   switch( event.eventId() )
   {
      case WM_DESTROY:
         stopDispatching = destroy( event );
         break;
   }
   return( stopDispatching );
}

Boolean GLPaintDestroy::destroy( IEvent &event )
{
   // stop the timer
   paintHandler->timer.stop();
   return false;
}

// constructors and destructors
GLPaintHandler::GLPaintHandler( IWindow &_window )
: window( _window ),  paintDestroy( this ),
  venus( 0.0 ), earth( 0.0 ), earthMoon( 0.0 ), earthSpin( 0.0 ), mars( 0.0 )
{
   // activate the destructor handler
   paintDestroy.handleEventsFor( &_window );

   // set timer
   timer
      .setInterval( 100 )
      .start( new ITimerMemberFn0<GLPaintHandler>( *this, GLPaintHandler::timerFn ));
}

GLPaintHandler::~GLPaintHandler()
{
   HAB hab = IThread::current().anchorBlock();

   // unbind the current context
   pglMakeCurrent( hab, NULL, NULL );

   // destroy the context we created
   pglDestroyContext( hab, hgc );
}

void GLPaintHandler::initOpenGL()
{
   int attribList[] = { PGL_RGBA, PGL_RED_SIZE, 2, PGL_GREEN_SIZE, 2,
      PGL_BLUE_SIZE, 2, PGL_DOUBLEBUFFER, 0 };

   // get a handle to anchor block
   HAB hab =  IThread::current().anchorBlock();

   // create a visual config
   PVISUALCONFIG pVisualConfig = pglChooseConfig( hab, attribList );

   // create a direct OpenGL context
   hgc = pglCreateContext( hab, pVisualConfig, NULL, true );

   // and make the context we got the current one
   Boolean val = pglMakeCurrent( hab, hgc, window.handle() );

   // enable depth buffer
   glEnable( GL_DEPTH_TEST );

   glClearColor( 0.0, 0.0, 0.0, 1.0 );
   glDrawBuffer( GL_FRONT_AND_BACK );
   glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT  );
   glDrawBuffer( GL_BACK );

   glPolygonMode( GL_FRONT_AND_BACK, GL_FILL );

   // free the visual config created above
   delete [] pVisualConfig;
}

void GLPaintHandler::initLighting()
{
   glEnable( GL_LIGHTING );
   // setup light 0
   glEnable( GL_LIGHT0 );
   glEnable( GL_COLOR_MATERIAL );

   // modify ambient light
   GLfloat amb_light[] = { 0.1, 0.1, 0.1, 1.0 };
   glLightModelfv( GL_LIGHT_MODEL_AMBIENT, amb_light );
}

// openGL settings
void GLPaintHandler::setWindowSize( ISize size )
{
   // setup the 3D perspective window
   glMatrixMode( GL_PROJECTION );
   glLoadIdentity();
   gluPerspective( FOVY, (float)window.size().width() / (float)window.size().height(),
                  MINVIEWDISTANCE, MAXVIEWDISTANCE );
   glMatrixMode( GL_MODELVIEW );
   // make a viewport the acual size of the window
   glViewport( 0, 0, size.width(), size.height() );
}

Boolean GLPaintHandler::paintWindow( IPaintEvent &event )
{
   // clear the buffer
   glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );

   // no rotations
   glLoadIdentity();

   // move the image back from the camera

   // tilt viewpoint an place on edge of planet
   glRotatef( 30, 1.0, 0.0, 0.0 );
   glTranslatef( 0.0, -5.0, 2.0 );
   // do a day rotation
   glRotatef( -earthSpin, 0.0, 1.0, 0.0 );
   glTranslatef( 0.0, 0.0, -600.0 );
   glRotatef( -90.0, 1.0, 0.0, 0.0 );
   // and rotate for the viewing position
   glRotatef( 90-earth, 0.0, 0.0, 1.0 );

   // draw a yellow sun
   // put light in middle of sun
   GLfloat light_pos[] = { 0, 0, 0, 1 };
   glLightfv( GL_LIGHT0, GL_POSITION, light_pos );
   // make sun full ambient
   GLfloat sun_emission[] = { 1.0, 1.0, 0.0, 1 };
   glMaterialfv( GL_FRONT, GL_EMISSION, sun_emission );
//   glColor3f( 1.0, 1.0, 0.0 );
   auxSolidSphere( 20.0 );

   // remember where we are
   glPushMatrix();

   // set planet lighting parameters
   GLfloat planet_emission[] = { 0.0, 0.0, 0.0, 1.0 };
   glMaterialfv( GL_FRONT, GL_EMISSION, planet_emission );

   // position venus
   glRotatef( venus, 0.0, 0.0, 1.0 );
   glTranslatef( -400.0, 0.0, 0.0 );
   // and draw it green
   glColor3f( 0.0, 1.0, 0.0 );
   auxSolidSphere( 5.0 );

   // restore old position
   glPopMatrix();

   // remember where we are
   glPushMatrix();

   // position the earth
   glRotatef( earth, 0.0, 0.0, 1.0 );
   glTranslatef( -600.0, 0.0, 0.0 );
   glPushMatrix();
   // do a day rotation
   glRotatef( earthSpin, 0.0, 0.0, 1.0 );
   // and draw it blue
   glColor3f( 0.0, 0.0, 1.0 );
   auxSolidSphere( 5.0 );

   glPopMatrix();
   //position the earth's moon
   glRotatef( earthMoon, 0.0, 0.0, 1.0 );
   glTranslatef( -20.0, 0.0, 0.0 );
   // and draw it grey
   glColor3f( 0.5, 0.5, 0.5 );
   auxSolidSphere( 1.0 );

   // restore old position
   glPopMatrix();

   // position mars
   glRotatef( mars, 0.0, 0.0, 1.0 );
   glTranslatef( -800.0, 0.0, 0.0 );
   // and draw it green
   glColor3f( 1.0, 0.0, 0.0 );
   auxSolidSphere( 3.0 );

   // swap the back draw buffer to the front
   pglSwapBuffers( IThread::current().anchorBlock(), window.handle() );

   // return true to indicate no additional processing needed
   return( true );
}

//private objects
void GLPaintHandler::timerFn()
{
   // recalculate positions
   venus += 0.01613;
   if( venus > 360.0 )
      venus -= 360.0;

   earth += 0.01;
   if( earth > 360.0 )
      earth -= 360.0;

   earthSpin += 3.6525;
   if( earthSpin > 360.0 )
      earthSpin -= 360.0;

   earthMoon += 0.1336;
   if( earthMoon > 360.0 )
      earthMoon -= 360.0;

   mars += 0.00532;
   if( mars > 360.0 )
      mars -= 360.0;

   window.refresh();
}

// window resize handler
Boolean GLResizeHandler::windowResize(IResizeEvent &event )
{
   // tell the paint handler the new size
   window->glPaintHandler().setWindowSize( event.newSize() );
   return false;
}

// constructor
GLWindow::GLWindow()
: IFrameWindow( "OpenGL Demonstration", 0x1000, IFrameWindow::defaultStyle()
         | IFrameWindow::noMoveWithOwner | IWindow::synchPaint ),
   canvas( 0x8008, this, this ),
   paintHandler( canvas ),
   resizeHandler( this )
{
   // setup
   setClient( &canvas );
   setDestroyOnClose( true );

   // draw on screen
   sizeTo( ISize( 400, 400 ));
   setFocus();
   show();

   // initialize openGL
   paintHandler.initOpenGL();
   paintHandler.initLighting();

   // set the size of the 3D window
   paintHandler.setWindowSize( canvas.size() );

   // attach the handlers
   paintHandler.handleEventsFor( &canvas );
   resizeHandler.handleEventsFor( &canvas );

}

// destructor
GLWindow::~GLWindow()
{

   // detach the handlers
   paintHandler.stopHandlingEventsFor( &canvas );
   resizeHandler.stopHandlingEventsFor( &canvas );
}
