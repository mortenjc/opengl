#include <pgl.h>

class GLWindow;
class GLPaintHandler;

#include <ihandler.hpp>
class GLPaintDestroy : public IHandler
{
   public:
      GLPaintDestroy( GLPaintHandler *_paintHandler )
      : paintHandler( _paintHandler )
      { }
   protected:
      virtual Boolean dispatchHandlerEvent( IEvent &event );
      virtual Boolean destroy( IEvent &event );
   private:
      GLPaintHandler *paintHandler;
};

#include <itimer.hpp>
#include <ipainhdr.hpp>
class GLPaintHandler : public IPaintHandler
{
   public:
      // constructor and destructor
      GLPaintHandler( IWindow &_window );
      ~GLPaintHandler();

      // openGL initialization routines
      void initOpenGL();
      void initLighting();

      // openGL settings
      void setWindowSize( ISize size );

      // timer function
      void timerFn();

      friend class GLPaintDestroy;

   protected:
      virtual Boolean paintWindow( IPaintEvent &event );

   private:
      ITimer timer;
      HGC hgc;
      GLPaintDestroy paintDestroy;
      IWindow &window;
      float venus, earth, earthSpin, earthMoon, mars;
};

#include <isizehdr.hpp>
class GLResizeHandler : public IResizeHandler
{
   public:
      GLResizeHandler( GLWindow *_window )
      : window( _window )
      { }
   protected:
      virtual Boolean windowResize( IResizeEvent &event );
   private:
      GLWindow *window;
};

#include <iframe.hpp>
#include <icanvas.hpp>
class GLWindow : public IFrameWindow
{
   public:
      // constructor
      GLWindow();
      ~GLWindow();

      // selectors
      GLPaintHandler &glPaintHandler() { return( paintHandler ); }

   private:
      // private objects
      ICanvas canvas;
      GLPaintHandler paintHandler;
      GLResizeHandler resizeHandler;
};

