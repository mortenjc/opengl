#include <ithread.hpp>
#include <imsgbox.hpp>
#include "glWindow.hpp"

int main( int argc, char *argv[] )
{
   try {
      // create the main window
      GLWindow *glWindow = new GLWindow;

      // main messaging processing loop
      IThread::current().processMsgs();
   }
   // catch and display any exceptions thown by the UIL
   catch( IException& exc )
   {
      IMessageBox prob(IWindow::desktopWindow());
      prob
         .setTitle( "Exception Caught" )
         .show(exc.text(), IMessageBox::okButton );
   }
   return 0;
}   //end main
